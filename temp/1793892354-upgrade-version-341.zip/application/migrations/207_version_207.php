<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Migration_Version_207 extends CI_Migration
{
    public function __construct()
    {
        parent::__construct();
    }

    public function up()
    {

    }
}
